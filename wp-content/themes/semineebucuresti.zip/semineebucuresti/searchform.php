<div class="form-wrapper">
    <form role="search" method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Cauta" value="" name="s" id="s" width="70%" />
            <button type="submit" title="Cautare" class="search-btn pull-right"><i class="fa fa-search search-icon-color" aria-hidden="true"></i></button>
        </div>
    </form>
</div>