<?php get_header(); ?>
<div class="container">
    <div class="row">
            <div class="col-md-3">
                <img src="<?php echo get_template_directory_uri().'/images/banner-home.jpg'; ?>" >
            </div>
            <div class="col-md-6 no-left-padding no-right-padding">
                <?php putUniteGallery("homesmall", 1); ?>            
            </div>
            <div class="col-md-3">
                <img src="<?php echo get_template_directory_uri().'/images/banner-home.jpg'; ?>" >
            </div>
        
    </div>   
    
    <div class="row">        
        <div class="block-title-w col-md-12">
            <h2 class="block-title">FABRICA DE FINISAJE PENTRU SEMINEE</h2>             
        </div>
    </div>
    
    <div style="clear: both;"></div>
    <div class="row">
        <div class="col-md-4 home-box-left text-center">
            <p class="home-box">Nu poate exista mai ieftin! Daca aveti contraoferte mai mici, acordam bonus de inca 10% fata de concurenta!*</p>
        </div>
        <div class="col-md-4 home-box-middle text-center">
            <p class="home-box">Va aşteptăm la cel mai mare showroom din ţară in bulevardul Iuliu Maniu nr. 273, Bucuresti, Sector 4, Mircea Seminee. </p>
        </div>
        <div class="col-md-4 home-box-right text-center">
            <p class="home-box">Consiliere gratuita in alegerea semineului, focarului sau cosului de fum - 0749 065 782 (ZILNIC: 07-21.00).</p>
        </div>
    </div>
    <!--
    <div class="row row-margin">
         <div class="col-md-12 home-box-about-wrapp">
            <p class="home-box-about">
            <img src="<?php echo get_template_directory_uri().'/images/home-banner-2.jpg';?>" alt="" >            
       
                The Ulrich Brunner GmbH<br><br>

                For more than 25 years the Ulrich Brunner GmbH has been specialised on manufacturing wood- fired heating devices, with a special focus on fireplaces and tiled stoves.

                Our expertise in this specific field makes it possible for us to meet our customer’s high and sometimes also extraordinary demands for fireplaces and stoves. During the first phase of concept development for a water-bearing fireplace or a water- bearing tiled stove you will see that we measure ourselves against the highest standards of quality. We are proud that we can clearly be differentiated from our competitors! Already the weight and the construction of all the different boilers, tiled stoves or fireplaces argue for high- quality processing. Whether you choose a fireplace, a stove, a tiled stove or a heating system made by BRUNNER, our heating- technology products are definitely worth their price!
                For the manufacturing of tiled stoves, fireplaces and stoves we strictly renounce cheap production abroad. Every fireplace or tiled stove (heating system or other fireplace system) you can purchase was entirely manufactured in Germany by skilled craftsmen. That means all devices are 100% Made in Germany.

                Our innovations and ideas for heating, fireplaces and basic stoves have already convinced many of our clients in Munich, Vienna, Salzburg, Hannover, Dresden and the Ruhr area. For example we introduced classical ornaments for special heating inserts, designed a grate-less insert for wood-firing and a envi!
            </p>
        </div>
    </div>
    -->
    <div style="clear: both;"></div>
    <div class="row row-wrapper">
    <?php
        $prod_categories = get_terms( array(
            'taxonomy'   => 'product_cat',
            'orderby'    => 'name',
            'order'      => 'ASC',
            'hide_empty' => 1
        ));
        
        foreach( $prod_categories as $prod_cat ) {
            $cat_thumb_id = get_woocommerce_term_meta( $prod_cat->term_id, 'thumbnail_id', true );
            $cat_thumb_url = wp_get_attachment_thumb_url( $cat_thumb_id );
            $term_link = get_term_link( $prod_cat, 'product_cat' ); 
        ?>
        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">     
            <div class="cat-wrapper">
            <a class="home-category-box" href="<?php echo $term_link; ?>">
                <img class="img-responsive" src="<?php echo $cat_thumb_url; ?>" alt="<?php echo $prod_cat->name; ?>" />
            </a> 
            <hr>
            <h2 class="heading3"><a href="<?php echo $term_link; ?>"><?php echo $prod_cat->name; ?>&nbsp;&nbsp;<i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
</a></h2>                     
            </div>
        </div>
        
        <?php } wp_reset_query(); ?>   
    </div> 
    <div class="row row-wrapper">
    <?php
        $prod_categories = get_terms( array(
            'taxonomy'   => 'product_cat',
            'orderby'    => 'name',
            'order'      => 'ASC',
            'hide_empty' => 1
        ));
        
        foreach( $prod_categories as $prod_cat ) {
            $cat_thumb_id = get_woocommerce_term_meta( $prod_cat->term_id, 'thumbnail_id', true );
            $cat_thumb_url = wp_get_attachment_thumb_url( $cat_thumb_id );
            $term_link = get_term_link( $prod_cat, 'product_cat' ); 
        ?>
        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">     
            <div class="cat-wrapper">
            <a class="home-category-box" href="<?php echo $term_link; ?>">
                <img class="img-responsive" src="<?php echo $cat_thumb_url; ?>" alt="<?php echo $prod_cat->name; ?>" />
            </a> 
            <hr>
            <h2 class="heading3"><a href="<?php echo $term_link; ?>"><?php echo $prod_cat->name; ?>&nbsp;&nbsp;<i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
</a></h2>                     
            </div>
        </div>
        
        <?php } wp_reset_query(); ?>   
    </div>    
</div>

    <div style="clear: both;"></div>
<?php get_footer(); ?>
