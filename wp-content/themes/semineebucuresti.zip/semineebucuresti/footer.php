<footer>    
    <div class="footer-wraper-1">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h3>UTILE</h3>
                    <hr>
                    <ul class="footer-links-1">
                        <li><a href="">Termeni si conditii</a></li>
                        <li><a href="">Conditii asigurare garantii</a></li>
                        <li><a href="">Cum comand?</a></li>
                        <li><a href="">Cum platesc?</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h3>INFORMATII CUMPARARE</h3>
                    <hr>
                    <ul class="footer-links-2">
                        <li><a href="">Informatii livrare</a></li>
                        <li><a href="">Costul transportului</a></li>
                        <li><a href="">Procedura retur produse</a></li>
                        <li><a href="">Oferte speciale</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h3>CATEGORII PRODUSE</h3>
                    <hr>
                    <ul class="footer-links-3">
                        <li><a href="">Seminee</a></li>
                        <li><a href="">Focare</a></li>
                        <li><a href="">Cosuri de fum</a></li>
                        <li><a href="">Sobe</a></li>
                    </ul>                      
                </div>
                <div class="col-md-3">
                    <h3>DESPRE NOI</h3>
                    <hr>
                    <ul class="footer-links-4">
                        <li><a href="">Contact</a></li>
                        <li><a href="">Cariere</a></li>
                        <li><a href="">Despre noi</a></li>
                        <li><a href=""><img src="<?php echo get_template_directory_uri().'/images/logo.png';?>" width="150"></a></li>
                    </ul>                      
                </div>
            </div>
        </div>
    </div>
    <div class="footer-wraper-2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>© 2016 Mircea Seminee SRL. Toate drepturile rezervate.</p>    
                </div>
            </div>
        </div>
    </div>
</footer>
    <?php wp_footer(); ?>
    </body>
</html>